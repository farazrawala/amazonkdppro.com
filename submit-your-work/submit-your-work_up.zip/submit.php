<?php

require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

function respond(bool $success, string $message, int $code = 200): void
{
    http_response_code($code);
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

$requiredFields = [
    'title' => 'Title',
    'firstName' => 'First name',
    'lastName' => 'Last name',
    'contactNumber' => 'Contact number',
    'email' => 'Email',
    'confirmEmail' => 'Confirm email',
    'country' => 'Country',
    'bookTitle' => 'Book title',
    'genre' => 'Genre',
    'synopsis' => 'Synopsis',
];

foreach ($requiredFields as $field => $label) {
    if (empty(trim($_POST[$field] ?? ''))) {
        respond(false, $label . ' is required.', 422);
    }
}

$email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
$confirmEmail = filter_var(trim($_POST['confirmEmail']), FILTER_VALIDATE_EMAIL);

if (!$email || !$confirmEmail) {
    respond(false, 'Please enter a valid email address.', 422);
}

if ($email !== $confirmEmail) {
    respond(false, 'Email addresses do not match.', 422);
}

if (empty($_FILES['manuscript']) || $_FILES['manuscript']['error'] === UPLOAD_ERR_NO_FILE) {
    respond(false, 'Please upload your manuscript file.', 422);
}

$file = $_FILES['manuscript'];

if ($file['error'] !== UPLOAD_ERR_OK) {
    respond(false, 'File upload failed. Please try again.', 422);
}

$allowedExtensions = ['pdf', 'doc', 'docx', 'txt'];
$maxSize = 10 * 1024 * 1024;
$originalName = $file['name'];
$extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

if (!in_array($extension, $allowedExtensions, true)) {
    respond(false, 'Invalid file type. Allowed: PDF, DOC, DOCX, TXT.', 422);
}

if ($file['size'] > $maxSize) {
    respond(false, 'File size must be less than 10MB.', 422);
}

$uploadDir = __DIR__ . '/uploads/manuscripts/';
if (!is_dir($uploadDir) && !mkdir($uploadDir, 0755, true)) {
    respond(false, 'Unable to create upload directory.', 500);
}

$safeBaseName = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($originalName, PATHINFO_FILENAME));
$storedName = date('Ymd_His') . '_' . uniqid() . '_' . $safeBaseName . '.' . $extension;
$destination = $uploadDir . $storedName;

if (!move_uploaded_file($file['tmp_name'], $destination)) {
    respond(false, 'Failed to save uploaded file.', 500);
}

$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';
$scriptDir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$fileUrl = $protocol . '://' . $host . $scriptDir . '/uploads/manuscripts/' . rawurlencode($storedName);

$formData = [
    'Title' => trim($_POST['title']),
    'First Name' => trim($_POST['firstName']),
    'Last Name' => trim($_POST['lastName']),
    'Contact Number' => trim($_POST['contactNumber']),
    'Email' => $email,
    'Street Address' => trim($_POST['street'] ?? ''),
    'Town/City' => trim($_POST['city'] ?? ''),
    'County/State' => trim($_POST['state'] ?? ''),
    'Postcode/Zipcode' => trim($_POST['postcode'] ?? ''),
    'Country' => trim($_POST['country']),
    'Book Title' => trim($_POST['bookTitle']),
    'Genre' => trim($_POST['genre']),
    'Synopsis' => trim($_POST['synopsis']),
    'Author Information' => trim($_POST['authorInfo'] ?? ''),
    'Manuscript File' => $originalName,
    'Download Link' => $fileUrl,
];

function buildEmailBody(array $formData, string $heading): string
{
    $rows = '';
    foreach ($formData as $label => $value) {
        if ($label === 'Download Link') {
            $value = '<a href="' . htmlspecialchars($value) . '">' . htmlspecialchars($value) . '</a>';
        } else {
            $value = nl2br(htmlspecialchars($value));
        }
        $rows .= '<tr>
            <td style="padding:12px;border:1px solid #e5e7eb;font-weight:600;background:#f9fafb;">' . htmlspecialchars($label) . '</td>
            <td style="padding:12px;border:1px solid #e5e7eb;">' . $value . '</td>
        </tr>';
    }

    return '<html><body style="font-family:Arial,sans-serif;color:#111;">
        <h2 style="color:#ff9900;">' . htmlspecialchars($heading) . '</h2>
        <p>A new manuscript submission has been received.</p>
        <table style="width:100%;border-collapse:collapse;margin:20px 0;">' . $rows . '</table>
        <p style="color:#666;font-size:12px;">Submitted on: ' . date('Y-m-d H:i:s') . '</p>
    </body></html>';
}

function sendMail(string $toEmail, string $toName, string $subject, string $body): void
{
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'mail.amazon-publishers.co';
    $mail->SMTPAuth = true;
    $mail->Username = 'leads@amazon-publishers.co';
    $mail->Password = 'leads@amazon-publishers.co';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;
    $mail->SMTPDebug = SMTP::DEBUG_OFF;

    $mail->setFrom('leads@amazon-publishers.co', 'Amazon Publishers');
    $mail->addAddress($toEmail, $toName);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $body;

    $mail->send();
}

try {
    $adminBody = buildEmailBody($formData, 'New Manuscript Submission - Amazon KDP Pro');
    sendMail('johndavid78663@gmail.com', 'Test Recipient', 'New Manuscript Submission - Amazon KDP Pro', $adminBody);

    $userBody = buildEmailBody($formData, 'Your Manuscript Submission Received');
    sendMail($email, trim($_POST['firstName'] . ' ' . $_POST['lastName']), 'Your Manuscript Submission - Amazon KDP Pro', $userBody);

    respond(true, 'Thank you! Your manuscript has been submitted successfully. A confirmation email has been sent to you.');
} catch (Exception $e) {
    if (file_exists($destination)) {
        unlink($destination);
    }
    respond(false, 'Submission could not be completed. Please try again later.', 500);
}
