<?php

require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

function respond(bool $success, string $message, int $code = 200): void
{
    http_response_code($code);
    echo json_encode(['success' => $success, 'message' => $message]);
    exit;
}

$name = trim($_POST['name'] ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$phone = trim($_POST['phone'] ?? '');
$brief = trim($_POST['brief'] ?? '');

if ($name === '') {
    respond(false, 'Full name is required.', 422);
}

if (!$email) {
    respond(false, 'Please enter a valid email address.', 422);
}

$formData = [
    'Full Name' => $name,
    'Email' => $email,
    'Phone Number' => $phone ?: 'Not provided',
    'About Your Book' => $brief ?: 'Not provided',
];

function buildEmailBody(array $formData, string $heading): string
{
    $rows = '';
    foreach ($formData as $label => $value) {
        $rows .= '<tr>
            <td style="padding:12px;border:1px solid #e5e7eb;font-weight:600;background:#f9fafb;">' . htmlspecialchars($label) . '</td>
            <td style="padding:12px;border:1px solid #e5e7eb;">' . nl2br(htmlspecialchars($value)) . '</td>
        </tr>';
    }

    return '<html><body style="font-family:Arial,sans-serif;color:#111;">
        <h2 style="color:#ff9900;">' . htmlspecialchars($heading) . '</h2>
        <p>A new consultation request has been received.</p>
        <table style="width:100%;border-collapse:collapse;margin:20px 0;">' . $rows . '</table>
        <p style="color:#666;font-size:12px;">Submitted on: ' . date('Y-m-d H:i:s') . '</p>
    </body></html>';
}

function sendMail(string $toEmail, string $toName, string $subject, string $body): void
{
    $mail = new PHPMailer(true);

    $mail->isSMTP();
    $mail->Host = 'mail.amazon-publishers.co';
    $mail->SMTPAuth = true;
    $mail->Username = 'leads@amazon-publishers.co';
    $mail->Password = 'leads@amazon-publishers.co';
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
    $mail->Port = 465;
    $mail->SMTPDebug = SMTP::DEBUG_OFF;

    $mail->setFrom('leads@amazon-publishers.co', 'Amazon Publishers');
    $mail->addAddress($toEmail, $toName);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = $body;

    $mail->send();
}

try {
    $adminBody = buildEmailBody($formData, 'New Consultation Request - Amazon KDP Pro');
    sendMail('johndavid78663@gmail.com', 'Test Recipient', 'New Consultation Request - Amazon KDP Pro', $adminBody);

    $userBody = buildEmailBody($formData, 'Your Consultation Request Received');
    sendMail($email, $name, 'Your Consultation Request - Amazon KDP Pro', $userBody);

    respond(true, 'Thank you! Your consultation request has been submitted. We will contact you shortly.');
} catch (Exception $e) {
    respond(false, 'Submission could not be completed. Please try again later.', 500);
}
